export interface User {
    email: string;
    name: string;
}
