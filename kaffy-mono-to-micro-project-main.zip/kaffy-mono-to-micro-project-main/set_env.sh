# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export POSTGRES_USERNAME=postgres
export POSTGRES_PASSWORD=ywCO38fYbJ9Ehl5#
export POSTGRES_HOST=alx-udacity-db.clv3deso9fxe.us-east-2.rds.amazonaws.com
export POSTGRES_DB=postgres
export AWS_BUCKET=alx-udacity-bucket
export AWS_REGION=us-east-2
export AWS_PROFILE=default
export JWT_SECRET=testing
export URL=http://localhost:8100
